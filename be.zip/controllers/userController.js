const express = require('express');
const userService = require('../services/userService');

const router = express.Router();

//일반 회원가입 요청
router.post('/register', async (req, res) => {
  const { id, nick, password } = req.body;
  const userData = { id, nick, password };
  console.log(req.body);

  try {
    const newUser = await userService.register(req.body);
    console.log(newUser);
    res.status(200).json(newUser);
  } catch (err) {
    res.json({ message: err.message });
  }
});

module.exports = router;
