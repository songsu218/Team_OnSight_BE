const User = require('../models/User');
const hashUtils = require('../utils/hashUtils');

async function register(userData) {
  console.log(userData);
  console.log(userData.id);
  console.log(userData.password);
  console.log(userData.nick);
  const userDoc = await User.create({
    id: userData.id,
    password: hashUtils.hashPassword(userData.password),
    nick: userData.nick,
    thumbnail: null,
    crews: [],
  });
  return userDoc;
}

module.exports = {
  register,
};
